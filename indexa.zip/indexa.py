import boto3
from elasticsearch import Elasticsearch, RequestsHttpConnection

s3 = boto3.resource('s3')
rekognition = boto3.client('rekognition')
esClient = boto3.client('es')

BUCKET = "search-objects"
KEY = "skyline.jpg"

# Conecta ao ElasticSearch
def connectES(esEndPoint):
 print ('Connecting to the ES Endpoint {0}'.format(esEndPoint))
 try:
  esClient = Elasticsearch(
   hosts=[{'host': esEndPoint, 'port': 443}],
   use_ssl=True,
   verify_certs=True,
   connection_class=RequestsHttpConnection)
  return esClient
 except Exception as E:
  print("Unable to connect to {0}".format(esEndPoint))
  print(E)
  exit(3)

esClient = connectES("search-pesquisa-kwt7smanldgreoeqvmit766rwy.us-east-1.es.amazonaws.com")

# Detecta objetos na imagem
def detect_labels(bucket, key, max_labels=5, min_confidence=90):
	response = rekognition.detect_labels(
		Image={
			"S3Object": {
				"Bucket": bucket,
				"Name": key,
			}
		},
		MaxLabels=max_labels,
		MinConfidence=min_confidence,
	)

	return response['Labels']

def cria_documento():
	labels = []
	for id, label in enumerate(detect_labels(BUCKET, KEY)):
		labels.append(label['Name'])
	# print('Label ' + label['Name'] + ', Confiança: ' + str(label['Confidence']))
	# print(elasticsearch.list_tags(ARN='arn:aws:es:us-east-1:666415158561:domain/pesquisa'))

	documento = {
		'titulo': 'https://s3.amazonaws.com/' + BUCKET + '/' + KEY,
		'labels': labels
	}
	# print(documento)
	esClient.index(index='imagens', doc_type='labels', body=documento)

def delete_index(name):
	esClient.indices.delete(index=name, ignore=[400, 404])

#delete_index('imagens')

def main(event, context):
	BUCKET = event.Records[0].s3.bucket.name
	KEY = event.Records[0].s3.object.key
	print(BUCKET)
	print(KEY)

